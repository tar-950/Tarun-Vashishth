.. osxpython documentation master file, created by
   sphinx-quickstart on Wed Aug  4 22:51:11 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Clint's Documentation!
=================================

Welcome to Clint. 

.. include:: contents.rst.inc